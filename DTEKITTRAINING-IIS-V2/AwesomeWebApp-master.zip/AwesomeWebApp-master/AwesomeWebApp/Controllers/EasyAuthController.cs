﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AwesomeWebApp.Controllers
{
    public class EasyAuthController : Controller
    {
        // GET: EasyAuth
        public ActionResult Index()
        {
            return View();
        }
    }
}