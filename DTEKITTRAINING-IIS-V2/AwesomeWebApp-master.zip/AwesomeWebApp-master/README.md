# AwesomeWebApp

This is a demo application which shows how to use specific features of Azure App Service.
